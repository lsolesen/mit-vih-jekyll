var store = [{
        "title": "Hvad bruger i Mit VIH til?",
        "excerpt":"Læs mere under Start.  ","categories": [],
        "tags": ["øvelser"],
        "url": "/faq/2017-08-23-hvad-er-hoejskolens-tilknytning-til-dif/",
        "teaser": null
      },{
        "title": "At træffe valg i livet",
        "excerpt":"At give deltagerne mulighed for at reflektere over egne valg i livet, almengøre valgsituationen og ruste deltagerne til at træffe valg i fremtiden. FFAST-modellen til planlægning Denne øvelse er beskrevet ud fra FFAST-modellen. Den enkelte lektion er på 45 minutter, hvilket kræver en god struktur både for vejlederen, men også...","categories": ["Vejledning"],
        "tags": ["vejledning","featured"],
        "url": "/gruppevejledning-og-vejledning-faellesskaber/",
        "teaser": "https://images.unsplash.com/photo-1460518451285-97b6aa326961?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&h=300&w=400&q=10"
      },{
        "title": "Fælles Narrativ Tidslinje",
        "excerpt":"Metoden Fælles Narrativ Tidslinje er oprindeligt udviklet af Denborough og tager afsæt i et omdrejningspunkt for narrativ terapi: Opdagelsen af unikke hændelser. En lignende teknik er kendt fra en psykodynamisk tilgang til vejledning (se fx Stern 2004). Et særligt kendetegn ved narrativ terapi her er udsagnet om det fraværende men...","categories": [],
        "tags": [],
        "url": "/faelles-narrativ-tidslinje/",
        "teaser": "https://images.unsplash.com/photo-1460518451285-97b6aa326961?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&h=300&w=400&q=10"
      },{
        "title": "Livstræet - the tree of life",
        "excerpt":"Oprindeligt er metoden udviklet af Ncazelo Ncube med henblik på afrikanske børn, som har mistet forældre og andre primære personer pga. HIV/AIDS og som følge deraf ofte lever under forhold præget af utryghed, vold og misbrug (Ncube 2006, 2007). Ncube ønskede med metoden at hjælpe børnene med at blive mere...","categories": [],
        "tags": [],
        "url": "/livstraeet-the-tree-of-life/",
        "teaser": "https://images.unsplash.com/photo-1460518451285-97b6aa326961?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&h=300&w=400&q=10"
      },]
